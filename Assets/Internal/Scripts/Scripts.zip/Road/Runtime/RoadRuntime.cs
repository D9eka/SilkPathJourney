#if UNITY_EDITOR
using UnityEditor;
#endif
using Internal.Scripts.World;
using UnityEngine;

namespace Internal.Scripts.Road.Runtime
{
    public class RoadRuntime : MonoBehaviour
    {
        private const float THICKNESS_CENTER = 6f;
        private const float THICKNESS_LANE = 4f;
        private const float THICKNESS_EDGE = 3f;
        
        private readonly Color _centerColor = new Color(1f, 1f, 0.2f, 1f);
        private readonly Color _edgeColor = new Color(1f, 0.6f, 0.2f, 1f);
        private readonly Color _leftLaneColor = new Color(0.2f, 1f, 1f, 1f);
        private readonly Color _rightLaneColor = new Color(1f, 0.4f, 1f, 1f);
        
        private RoadPolylineSampler _sampler;
        private float _step;
        
        private float _arrowEvery;
        private float _arrowSize;
        
        public RoadData Data { get; set; }
        public Transform Parent { get; set; }

        public void SetWorldRoot(Transform root) => Parent = root;

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (Data == null || Data.PointsLocal == null || Data.PointsLocal.Count < 2)
                return;

            _sampler = new RoadPolylineSampler(Data.PointsLocal);

            float laneW = Mathf.Max(0.01f, Data.LaneWidth);
            int laneCount = Mathf.Max(1, Data.LaneCount);
            float oCenter = 0f;
            float halfRoad = laneCount * laneW * 0.5f;

            _step = Mathf.Max(1f, Data.SampleStepMeters);
            _arrowEvery = Mathf.Max(10f, _step * 5f);
            _arrowSize = Mathf.Max(0.5f, laneW * 0.6f);
            
            DrawEdges(halfRoad);
            DrawLanes(laneCount, laneW, true);
            DrawOffsetLine(oCenter, THICKNESS_CENTER, _centerColor);
        }

        private void DrawEdges(float halfRoad, bool needArrows = false)
        {
            float oEdgeL = -halfRoad;
            float oEdgeR = +halfRoad;
            
            DrawOffsetLine(oEdgeL, THICKNESS_EDGE, _edgeColor, needArrows);
            DrawOffsetLine(oEdgeR, THICKNESS_EDGE, _edgeColor, needArrows);
        }

        private void DrawLanes(int laneCount, float laneW, bool needArrow = false)
        {
            float oLaneL = (laneCount >= 2) ? -laneW * 0.5f : 0f;
            float oLaneR = (laneCount >= 2) ? +laneW * 0.5f : 0f;
            
            DrawOffsetLine(oLaneL, THICKNESS_LANE, _leftLaneColor, needArrow);
            DrawOffsetLine(oLaneR, THICKNESS_LANE, _rightLaneColor, needArrow);
        }
        
        private void DrawOffsetLine(float lateralOffset, float thickness, Color color, bool drawArrows = false)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always; // draw on top
            Handles.color = color;

            Vector3 prev = SampleWorld(0f, lateralOffset);
            for (float d = _step; d <= _sampler.Length; d += _step)
            {
                Vector3 cur = SampleWorld(d, lateralOffset);
                Handles.DrawAAPolyLine(thickness, prev, cur);
                prev = cur;
            }

            Vector3 last = SampleWorld(_sampler.Length, lateralOffset);
            Handles.DrawAAPolyLine(thickness, prev, last);

            if (drawArrows)
                DrawArrows(lateralOffset);
        }

        private void DrawArrows(float lateralOffset)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            Handles.color = Color.white;

            for (float d = 0f; d <= _sampler.Length; d += _arrowEvery)
            {
                Vector3 pLocal = _sampler.GetPositionLocal(d);
                Vector3 tLocal = _sampler.GetTangentLocal(d);
                Vector3 rLocal = _sampler.GetRightLocal(d);

                Vector3 p = ToWorld(pLocal + rLocal * lateralOffset);
                Vector3 dir = DirToWorld(tLocal).normalized;

                if (dir.sqrMagnitude < 1e-6f) continue;

                // Simple arrow: line + V head
                Vector3 a = p;
                Vector3 b = p + dir * _arrowSize;

                Handles.DrawAAPolyLine(3f, a, b);

                // Arrow head
                Vector3 side = Vector3.Cross(Vector3.up, dir).normalized;
                float headLen = _arrowSize * 0.35f;
                Vector3 headA = b - dir * headLen + side * headLen * 0.7f;
                Vector3 headB = b - dir * headLen - side * headLen * 0.7f;
                Handles.DrawAAPolyLine(3f, b, headA);
                Handles.DrawAAPolyLine(3f, b, headB);
            }
        }

        private Vector3 SampleWorld(float dist, float lateralOffset)
        {
            Vector3 pLocal = _sampler.GetPositionLocal(dist);
            Vector3 right = _sampler.GetRightLocal(dist);
            return ToWorld(pLocal + right * lateralOffset);
        }
        
        private Vector3 ToWorld(Vector3 pLocal) => Parent != null ? Parent.TransformPoint(pLocal) : pLocal;
        private Vector3 DirToWorld(Vector3 dirLocal) => Parent != null ? Parent.TransformDirection(dirLocal) : dirLocal;
#endif
    }
}
