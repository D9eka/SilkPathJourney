namespace Internal.Scripts.Road
{
    public enum RoadLane
    {
        Center = 0,
        Right = 1,
        Left = -1
    }
}