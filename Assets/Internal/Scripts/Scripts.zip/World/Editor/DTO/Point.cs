using System;

namespace Internal.Scripts.World.Editor.DTO
{
    [Serializable]
    public class Point
    {
        public float X, Y, Z;
    }
}