using System;

namespace Internal.Scripts.World.Editor.DTO
{
    [Serializable] 
    public class Endpoints
    {
        public string StartNodeId;
        public string EndNodeId;
    }
}