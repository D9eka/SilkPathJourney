namespace Internal.Scripts.World
{
    public enum WorldViewMode
    {
        CityIso,
        RouteMap,
        Artistic
    }
}