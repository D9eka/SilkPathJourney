namespace Internal.Scripts.World
{
    public enum WorldDetailLevel
    {
        Full,
        Simplified,
        Symbolic
    }
}